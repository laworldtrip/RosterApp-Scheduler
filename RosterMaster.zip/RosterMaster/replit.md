# Overview

HotelRoster Pro is a comprehensive hotel staff scheduling and roster management application designed to streamline workforce planning for hotel operations. The system provides automated roster generation based on occupancy forecasts, staff availability, and business rules while offering intuitive drag-and-drop interfaces for manual adjustments. Key features include staff management, availability tracking, occupancy forecasting, shift scheduling, and conflict resolution capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built using React with TypeScript, leveraging modern UI patterns and state management:

- **React SPA**: Single-page application with client-side routing using Wouter
- **UI Framework**: Shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query for server state management and caching
- **Form Handling**: React Hook Form with Zod schema validation
- **Drag & Drop**: Custom drag-and-drop context for roster manipulation
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
Express.js-based REST API server providing comprehensive workforce management endpoints:

- **Framework**: Express.js with TypeScript for type safety
- **API Design**: RESTful endpoints for CRUD operations on staff, shifts, availability, and occupancy
- **Database Layer**: Drizzle ORM with PostgreSQL for type-safe database operations
- **Business Logic**: Roster generation algorithms with conflict detection and fairness scoring
- **Error Handling**: Centralized error middleware with proper HTTP status codes

## Data Storage
PostgreSQL database with Drizzle ORM providing type-safe database interactions:

- **Schema Design**: Normalized tables for users, staff, availability, shifts, occupancy forecasts, and roster templates
- **Data Types**: Enum types for staff classifications, shift types, and availability statuses
- **Relationships**: Foreign key relationships maintaining data integrity
- **Migrations**: Drizzle Kit for database schema versioning and migrations

## Authentication & Authorization
Basic user management system with role-based access:

- **User Model**: Username/password authentication with role assignment
- **Session Management**: Session-based authentication for secure API access
- **Role System**: Manager role with plans for additional role types

## External Dependencies

- **Database**: Neon serverless PostgreSQL for cloud-hosted database with connection pooling
- **UI Components**: Radix UI for accessible, unstyled component primitives
- **Styling**: Tailwind CSS for utility-first styling with custom design tokens
- **Date Handling**: date-fns for comprehensive date manipulation and formatting
- **Validation**: Zod for runtime type validation and schema definition
- **Build Tools**: ESBuild for server bundling, PostCSS for CSS processing
- **Development**: Replit integration with Vite for development environment