import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, startOfWeek, endOfWeek, addWeeks, subWeeks } from "date-fns";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import RosterGrid from "@/components/roster/roster-grid";
import OccupancyPanel from "@/components/panels/occupancy-panel";
import AvailabilityPanel from "@/components/panels/availability-panel";
import QuickActionsPanel from "@/components/panels/quick-actions-panel";
import ConflictResolutionModal from "@/components/modals/conflict-resolution-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Bed, CalendarCheck, AlertTriangle } from "lucide-react";

export default function Dashboard() {
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [showConflictModal, setShowConflictModal] = useState(false);

  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 });

  const { data: staff = [] } = useQuery({
    queryKey: ['/api/staff'],
  });

  const { data: shifts = [] } = useQuery({
    queryKey: ['/api/shifts', format(weekStart, 'yyyy-MM-dd'), format(weekEnd, 'yyyy-MM-dd')],
    queryFn: async ({ queryKey }) => {
      const [, startDate, endDate] = queryKey;
      const response = await fetch(`/api/shifts?startDate=${startDate}&endDate=${endDate}`);
      if (!response.ok) throw new Error('Failed to fetch shifts');
      return response.json();
    },
  });

  const { data: occupancy = [] } = useQuery({
    queryKey: ['/api/occupancy', format(weekStart, 'yyyy-MM-dd'), format(weekEnd, 'yyyy-MM-dd')],
    queryFn: async ({ queryKey }) => {
      const [, startDate, endDate] = queryKey;
      const response = await fetch(`/api/occupancy?startDate=${startDate}&endDate=${endDate}`);
      if (!response.ok) throw new Error('Failed to fetch occupancy');
      return response.json();
    },
  });

  // Calculate stats
  const totalStaff = staff.length;
  const avgOccupancy = occupancy.length > 0 
    ? Math.round(occupancy.reduce((sum: number, o: any) => sum + parseFloat(o.occupancyRate), 0) / occupancy.length)
    : 0;
  const scheduledShifts = shifts.length;
  const conflicts = shifts.filter((shift: any) => shift.conflicted).length;

  const handlePreviousWeek = () => setCurrentWeek(prev => subWeeks(prev, 1));
  const handleNextWeek = () => setCurrentWeek(prev => addWeeks(prev, 1));

  return (
    <div className="min-h-screen bg-slate-50" data-testid="dashboard-page">
      <Sidebar />
      
      <div className="ml-64 flex flex-col min-h-screen">
        <Header 
          title="Roster Management Dashboard"
          subtitle={`Week of ${format(weekStart, 'MMM dd')} - ${format(weekEnd, 'dd, yyyy')}`}
          onPreviousWeek={handlePreviousWeek}
          onNextWeek={handleNextWeek}
        />
        
        <main className="flex-1 p-6">
          {/* Quick Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-600 text-sm font-medium">Total Staff</p>
                    <p className="text-2xl font-bold text-slate-800" data-testid="stat-total-staff">
                      {totalStaff}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Users className="text-brand-blue" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-600 text-sm font-medium">Avg. Occupancy</p>
                    <p className="text-2xl font-bold text-slate-800" data-testid="stat-avg-occupancy">
                      {avgOccupancy}%
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Bed className="text-brand-green" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-600 text-sm font-medium">Scheduled Shifts</p>
                    <p className="text-2xl font-bold text-slate-800" data-testid="stat-scheduled-shifts">
                      {scheduledShifts}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                    <CalendarCheck className="text-brand-amber" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-600 text-sm font-medium">Conflicts</p>
                    <p className="text-2xl font-bold text-brand-red" data-testid="stat-conflicts">
                      {conflicts}
                    </p>
                  </div>
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <AlertTriangle className="text-brand-red" size={24} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <RosterGrid 
                staff={staff}
                shifts={shifts}
                currentWeek={currentWeek}
                onPreviousWeek={handlePreviousWeek}
                onNextWeek={handleNextWeek}
                onConflictClick={() => setShowConflictModal(true)}
              />
            </div>
            
            <div className="space-y-6">
              <OccupancyPanel occupancy={occupancy} weekStart={weekStart} />
              <AvailabilityPanel />
              <QuickActionsPanel />
            </div>
          </div>
        </main>
      </div>

      <ConflictResolutionModal 
        open={showConflictModal}
        onOpenChange={setShowConflictModal}
      />
    </div>
  );
}
