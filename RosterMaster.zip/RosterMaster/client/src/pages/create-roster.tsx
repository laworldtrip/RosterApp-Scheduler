import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, startOfWeek, endOfWeek, addWeeks, subWeeks } from "date-fns";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import RosterGrid from "@/components/roster/roster-grid";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Wand2, Save, FileText, Send } from "lucide-react";

export default function CreateRoster() {
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 });

  const { data: staff = [] } = useQuery({
    queryKey: ['/api/staff'],
  });

  const { data: shifts = [] } = useQuery({
    queryKey: ['/api/shifts', format(weekStart, 'yyyy-MM-dd'), format(weekEnd, 'yyyy-MM-dd')],
    queryFn: async ({ queryKey }) => {
      const [, startDate, endDate] = queryKey;
      const response = await fetch(`/api/shifts?startDate=${startDate}&endDate=${endDate}`);
      if (!response.ok) throw new Error('Failed to fetch shifts');
      return response.json();
    },
  });

  const generateRosterMutation = useMutation({
    mutationFn: async () => {
      setIsGenerating(true);
      const response = await apiRequest('POST', '/api/roster/generate', {
        startDate: format(weekStart, 'yyyy-MM-dd'),
        endDate: format(weekEnd, 'yyyy-MM-dd'),
      });
      return response.json();
    },
    onSuccess: (data) => {
      setIsGenerating(false);
      toast({
        title: "Roster Generated",
        description: `Generated ${data.generatedShifts.length} shifts successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/shifts'] });
    },
    onError: () => {
      setIsGenerating(false);
      toast({
        title: "Error",
        description: "Failed to generate roster",
        variant: "destructive",
      });
    },
  });

  const handlePreviousWeek = () => setCurrentWeek(prev => subWeeks(prev, 1));
  const handleNextWeek = () => setCurrentWeek(prev => addWeeks(prev, 1));

  const handleGenerateRoster = () => {
    generateRosterMutation.mutate();
  };

  const handleSaveRoster = () => {
    toast({
      title: "Roster Saved",
      description: "All changes have been saved successfully",
    });
  };

  const handleExportRoster = () => {
    toast({
      title: "Export Started",
      description: "Roster export will be available shortly",
    });
  };

  const handleSendNotifications = () => {
    toast({
      title: "Notifications Sent",
      description: "Roster notifications have been sent to all staff",
    });
  };

  const totalHours = shifts.reduce((sum: number, shift: any) => sum + parseFloat(shift.hours || 0), 0);

  return (
    <div className="min-h-screen bg-slate-50" data-testid="create-roster-page">
      <Sidebar />
      
      <div className="ml-64 flex flex-col min-h-screen">
        <Header 
          title="Create Weekly Roster"
          subtitle={`Week of ${format(weekStart, 'MMM dd')} - ${format(weekEnd, 'dd, yyyy')}`}
          onPreviousWeek={handlePreviousWeek}
          onNextWeek={handleNextWeek}
        />
        
        <main className="flex-1 p-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <RosterGrid 
                staff={staff}
                shifts={shifts}
                currentWeek={currentWeek}
                onPreviousWeek={handlePreviousWeek}
                onNextWeek={handleNextWeek}
                editable={true}
              />
            </div>
            
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Roster Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button 
                    onClick={handleGenerateRoster}
                    disabled={isGenerating}
                    className="w-full bg-brand-blue hover:bg-blue-600"
                    data-testid="button-generate-roster"
                  >
                    <Wand2 className="w-4 h-4 mr-2" />
                    {isGenerating ? 'Generating...' : 'Auto Generate Roster'}
                  </Button>
                  
                  <Separator />
                  
                  <Button 
                    variant="outline" 
                    onClick={handleSaveRoster}
                    className="w-full"
                    data-testid="button-save-roster"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={handleExportRoster}
                    className="w-full"
                    data-testid="button-export-roster"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Export to PDF
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    onClick={handleSendNotifications}
                    className="w-full"
                    data-testid="button-send-notifications"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Send Notifications
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Roster Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-slate-800" data-testid="summary-total-shifts">
                        {shifts.length}
                      </p>
                      <p className="text-xs text-slate-600">Total Shifts</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-slate-800" data-testid="summary-total-hours">
                        {Math.round(totalHours)}
                      </p>
                      <p className="text-xs text-slate-600">Total Hours</p>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h4 className="text-sm font-medium text-slate-800 mb-2">Staff Distribution</h4>
                    <div className="space-y-2">
                      {['full-time', 'part-time', 'casual'].map((type) => {
                        const typeShifts = shifts.filter((s: any) => s.staff?.staffType === type);
                        const typeHours = typeShifts.reduce((sum: number, s: any) => sum + parseFloat(s.hours || 0), 0);
                        
                        return (
                          <div key={type} className="flex justify-between items-center text-sm">
                            <span className="capitalize text-slate-600">{type}</span>
                            <span className="font-medium text-slate-800">
                              {typeShifts.length} shifts ({Math.round(typeHours)}h)
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Generation Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-slate-600 mb-2">Auto-generation considers:</p>
                    <ul className="text-xs text-slate-500 space-y-1">
                      <li>• Hotel occupancy forecasts</li>
                      <li>• Staff availability preferences</li>
                      <li>• Fair distribution requirements</li>
                      <li>• Contract hour obligations</li>
                      <li>• Previous shift patterns</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
