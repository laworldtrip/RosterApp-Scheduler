import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, startOfWeek, endOfWeek, addWeeks, subWeeks, startOfDay, addDays } from "date-fns";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import OccupancyForm from "@/components/forms/occupancy-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Edit, Plus } from "lucide-react";
import type { OccupancyForecast } from "@shared/schema";

export default function OccupancyForecast() {
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [selectedForecast, setSelectedForecast] = useState<OccupancyForecast | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentWeek, { weekStartsOn: 1 });

  const { data: occupancy = [], isLoading } = useQuery({
    queryKey: ['/api/occupancy', format(weekStart, 'yyyy-MM-dd'), format(weekEnd, 'yyyy-MM-dd')],
    queryFn: async ({ queryKey }) => {
      const [, startDate, endDate] = queryKey;
      const response = await fetch(`/api/occupancy?startDate=${startDate}&endDate=${endDate}`);
      if (!response.ok) throw new Error('Failed to fetch occupancy');
      return response.json();
    },
  });

  const handlePreviousWeek = () => setCurrentWeek(prev => subWeeks(prev, 1));
  const handleNextWeek = () => setCurrentWeek(prev => addWeeks(prev, 1));

  const handleEdit = (forecast: OccupancyForecast) => {
    setSelectedForecast(forecast);
    setSelectedDate(null);
    setShowForm(true);
  };

  const handleAddForDate = (date: Date) => {
    setSelectedForecast(null);
    setSelectedDate(date);
    setShowForm(true);
  };

  const getDayForecast = (date: Date) => {
    return occupancy.find((f: OccupancyForecast) => 
      format(new Date(f.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );
  };

  const getProgressColor = (rate: number) => {
    if (rate >= 90) return "bg-brand-green";
    if (rate >= 75) return "bg-brand-blue";
    if (rate >= 50) return "bg-brand-amber";
    return "bg-slate-400";
  };

  // Generate week days
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  return (
    <div className="min-h-screen bg-slate-50" data-testid="occupancy-forecast-page">
      <Sidebar />
      
      <div className="ml-64 flex flex-col min-h-screen">
        <Header 
          title="Occupancy Forecast"
          subtitle={`Week of ${format(weekStart, 'MMM dd')} - ${format(weekEnd, 'dd, yyyy')}`}
          onPreviousWeek={handlePreviousWeek}
          onNextWeek={handleNextWeek}
        />
        
        <main className="flex-1 p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Overview</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="text-center py-8">Loading forecasts...</div>
                ) : (
                  <div className="space-y-4">
                    {weekDays.map((date) => {
                      const forecast = getDayForecast(date);
                      const rate = forecast ? parseFloat(forecast.occupancyRate) : 0;
                      
                      return (
                        <div key={date.toISOString()} className="flex justify-between items-center" data-testid={`row-occupancy-${format(date, 'yyyy-MM-dd')}`}>
                          <div>
                            <p className="text-sm font-medium text-slate-800" data-testid={`text-day-${format(date, 'yyyy-MM-dd')}`}>
                              {format(date, 'EEEE')}
                            </p>
                            <p className="text-xs text-slate-500" data-testid={`text-date-${format(date, 'yyyy-MM-dd')}`}>
                              {format(date, 'MMM dd')}
                            </p>
                          </div>
                          <div className="flex items-center space-x-4 flex-1 max-w-xs">
                            <div className="flex-1">
                              <Progress 
                                value={rate} 
                                className="h-2" 
                                data-testid={`progress-${format(date, 'yyyy-MM-dd')}`}
                              />
                            </div>
                            <span className="text-sm font-medium text-slate-800 w-12 text-right" data-testid={`text-rate-${format(date, 'yyyy-MM-dd')}`}>
                              {rate}%
                            </span>
                            <div className="flex space-x-1">
                              {forecast ? (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleEdit(forecast)}
                                  data-testid={`button-edit-${format(date, 'yyyy-MM-dd')}`}
                                >
                                  <Edit className="w-3 h-3" />
                                </Button>
                              ) : (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleAddForDate(date)}
                                  data-testid={`button-add-${format(date, 'yyyy-MM-dd')}`}
                                >
                                  <Plus className="w-3 h-3" />
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Forecasting Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-medium text-slate-800 mb-3">Weekly Statistics</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-3 bg-slate-50 rounded-lg">
                        <p className="text-2xl font-bold text-slate-800" data-testid="stat-avg-occupancy">
                          {occupancy.length > 0 
                            ? Math.round(occupancy.reduce((sum: number, f: OccupancyForecast) => sum + parseFloat(f.occupancyRate), 0) / occupancy.length)
                            : 0}%
                        </p>
                        <p className="text-xs text-slate-600">Average Occupancy</p>
                      </div>
                      <div className="text-center p-3 bg-slate-50 rounded-lg">
                        <p className="text-2xl font-bold text-slate-800" data-testid="stat-peak-occupancy">
                          {occupancy.length > 0 
                            ? Math.max(...occupancy.map((f: OccupancyForecast) => parseFloat(f.occupancyRate)))
                            : 0}%
                        </p>
                        <p className="text-xs text-slate-600">Peak Occupancy</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium text-slate-800 mb-3">Staffing Recommendations</h4>
                    <div className="space-y-2">
                      {occupancy.length === 0 ? (
                        <p className="text-sm text-slate-500">No forecasts available for recommendations.</p>
                      ) : (
                        occupancy
                          .sort((a: OccupancyForecast, b: OccupancyForecast) => parseFloat(b.occupancyRate) - parseFloat(a.occupancyRate))
                          .slice(0, 3)
                          .map((forecast: OccupancyForecast) => (
                            <div key={forecast.id} className="flex justify-between items-center p-2 bg-slate-50 rounded">
                              <span className="text-sm text-slate-700">
                                {format(new Date(forecast.date), 'EEE, MMM dd')}
                              </span>
                              <span className="text-sm font-medium text-slate-800">
                                High demand - Consider extra staff
                              </span>
                            </div>
                          ))
                      )}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-200">
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => {
                        setSelectedForecast(null);
                        setSelectedDate(null);
                        setShowForm(true);
                      }}
                      data-testid="button-bulk-update"
                    >
                      Bulk Update Forecasts
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {selectedForecast ? 'Edit Occupancy Forecast' : 'Add Occupancy Forecast'}
            </DialogTitle>
          </DialogHeader>
          <OccupancyForm
            forecast={selectedForecast}
            selectedDate={selectedDate}
            onSuccess={() => {
              setShowForm(false);
              setSelectedForecast(null);
              setSelectedDate(null);
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
