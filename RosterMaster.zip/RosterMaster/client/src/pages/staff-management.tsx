import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";
import StaffForm from "@/components/forms/staff-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Edit2, Trash2, Mail, Phone } from "lucide-react";
import type { Staff } from "@shared/schema";

export default function StaffManagement() {
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();

  const { data: staff = [], isLoading } = useQuery({
    queryKey: ['/api/staff'],
  });

  const deleteStaffMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest('DELETE', `/api/staff/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/staff'] });
      toast({
        title: "Success",
        description: "Staff member deleted successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete staff member",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (staff: Staff) => {
    setSelectedStaff(staff);
    setShowForm(true);
  };

  const handleAdd = () => {
    setSelectedStaff(null);
    setShowForm(true);
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this staff member?")) {
      deleteStaffMutation.mutate(id);
    }
  };

  const getStaffTypeBadge = (type: string) => {
    const variants = {
      'full-time': 'bg-brand-blue text-white',
      'part-time': 'bg-brand-green text-white',
      'casual': 'bg-brand-amber text-white',
    };
    return variants[type as keyof typeof variants] || 'default';
  };

  return (
    <div className="min-h-screen bg-slate-50" data-testid="staff-management-page">
      <Sidebar />
      
      <div className="ml-64 flex flex-col min-h-screen">
        <Header 
          title="Staff Management"
          subtitle="Manage your hotel staff members and their details"
        />
        
        <main className="flex-1 p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-slate-800">All Staff Members</h2>
            <Button onClick={handleAdd} data-testid="button-add-staff">
              <Plus className="w-4 h-4 mr-2" />
              Add Staff Member
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Staff Directory</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">Loading staff...</div>
              ) : staff.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  No staff members found. Add your first staff member to get started.
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Rate</TableHead>
                      <TableHead>Hours</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {staff.map((member: Staff) => (
                      <TableRow key={member.id} data-testid={`row-staff-${member.id}`}>
                        <TableCell>
                          <div>
                            <p className="font-medium text-slate-800" data-testid={`text-staff-name-${member.id}`}>
                              {member.firstName} {member.lastName}
                            </p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <Mail className="w-3 h-3 text-slate-400" />
                              <span className="text-sm text-slate-600">{member.email}</span>
                            </div>
                            {member.phone && (
                              <div className="flex items-center space-x-2">
                                <Phone className="w-3 h-3 text-slate-400" />
                                <span className="text-sm text-slate-600">{member.phone}</span>
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStaffTypeBadge(member.staffType)}>
                            {member.staffType}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {member.hourlyRate ? `$${member.hourlyRate}/hr` : '-'}
                        </TableCell>
                        <TableCell>
                          {member.contractedHours || '-'} hrs/week
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEdit(member)}
                              data-testid={`button-edit-${member.id}`}
                            >
                              <Edit2 className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDelete(member.id)}
                              disabled={deleteStaffMutation.isPending}
                              data-testid={`button-delete-${member.id}`}
                            >
                              <Trash2 className="w-3 h-3 text-red-500" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {selectedStaff ? 'Edit Staff Member' : 'Add Staff Member'}
            </DialogTitle>
          </DialogHeader>
          <StaffForm
            staff={selectedStaff}
            onSuccess={() => {
              setShowForm(false);
              setSelectedStaff(null);
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
