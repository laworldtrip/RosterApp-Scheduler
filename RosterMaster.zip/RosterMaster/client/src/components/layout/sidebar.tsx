import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Users, 
  Bed, 
  CalendarPlus,
  BarChart3, 
  Settings, 
  LogOut,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

const navigation = [
  { name: 'Dashboard', href: '/', icon: LayoutDashboard },
  { name: 'Create Roster', href: '/roster', icon: CalendarPlus },
  { name: 'Staff Management', href: '/staff', icon: Users },
  { name: 'Occupancy Forecast', href: '/occupancy', icon: Bed },
  { name: 'Reports', href: '/reports', icon: BarChart3 },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export default function Sidebar() {
  const [location] = useLocation();

  const handleLogout = () => {
    // TODO: Implement logout functionality
    console.log('Logout clicked');
  };

  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg border-r border-slate-200" data-testid="sidebar">
      {/* Logo Section */}
      <div className="flex items-center px-6 py-4 border-b border-slate-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-brand-blue rounded-lg flex items-center justify-center">
            <Calendar className="text-white" size={16} />
          </div>
          <h1 className="text-xl font-bold text-slate-800">HotelRoster Pro</h1>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="mt-6 px-3">
        <div className="space-y-1">
          {navigation.map((item) => {
            const isActive = location === item.href || (location === '/dashboard' && item.href === '/');
            return (
              <Link key={item.name} href={item.href}>
                <a
                  className={cn(
                    "group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors",
                    isActive
                      ? "bg-brand-blue text-white"
                      : "text-slate-700 hover:bg-slate-100"
                  )}
                  data-testid={`link-${item.name.toLowerCase().replace(' ', '-')}`}
                >
                  <item.icon className="mr-3" size={16} />
                  {item.name}
                </a>
              </Link>
            );
          })}
        </div>
      </nav>

      {/* User Profile Section */}
      <div className="absolute bottom-0 w-full p-4 border-t border-slate-200">
        <div className="flex items-center space-x-3">
          <Avatar className="w-8 h-8">
            <AvatarFallback className="bg-slate-300 text-slate-600 text-xs">
              SJ
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-700" data-testid="text-user-name">
              Sarah Johnson
            </p>
            <p className="text-xs text-slate-500" data-testid="text-user-role">
              Hotel Manager
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="text-slate-400 hover:text-slate-600 p-1"
            data-testid="button-logout"
          >
            <LogOut size={16} />
          </Button>
        </div>
      </div>
    </div>
  );
}
