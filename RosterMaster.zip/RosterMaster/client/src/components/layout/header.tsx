import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Wand2, Save, Bell } from "lucide-react";

interface HeaderProps {
  title: string;
  subtitle: string;
  onPreviousWeek?: () => void;
  onNextWeek?: () => void;
  showRosterActions?: boolean;
  onGenerateRoster?: () => void;
  onSaveRoster?: () => void;
}

export default function Header({ 
  title, 
  subtitle, 
  onPreviousWeek, 
  onNextWeek,
  showRosterActions = false,
  onGenerateRoster,
  onSaveRoster
}: HeaderProps) {
  return (
    <header className="bg-white shadow-sm border-b border-slate-200 px-6 py-4" data-testid="header">
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div>
            <h2 className="text-2xl font-bold text-slate-800" data-testid="text-header-title">
              {title}
            </h2>
            <div className="flex items-center space-x-2 mt-1">
              {onPreviousWeek && onNextWeek && (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onPreviousWeek}
                    data-testid="button-previous-week"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onNextWeek}
                    data-testid="button-next-week"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </>
              )}
              <p className="text-slate-600" data-testid="text-header-subtitle">
                {subtitle}
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          {showRosterActions && (
            <>
              <Button 
                className="bg-brand-blue hover:bg-blue-600"
                onClick={onGenerateRoster}
                data-testid="button-header-generate"
              >
                <Wand2 className="w-4 h-4 mr-2" />
                Auto Generate Roster
              </Button>
              <Button 
                className="bg-brand-green hover:bg-green-600"
                onClick={onSaveRoster}
                data-testid="button-header-save"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </>
          )}
          
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              className="text-slate-400 hover:text-slate-600"
              data-testid="button-notifications"
            >
              <Bell size={18} />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-brand-red rounded-full text-xs"></span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
