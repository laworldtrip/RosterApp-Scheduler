import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertOccupancyForecastSchema, type InsertOccupancyForecast, type OccupancyForecast } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface OccupancyFormProps {
  forecast?: OccupancyForecast | null;
  selectedDate?: Date | null;
  onSuccess: () => void;
}

export default function OccupancyForm({ forecast, selectedDate, onSuccess }: OccupancyFormProps) {
  const { toast } = useToast();
  const isEditing = !!forecast;

  const form = useForm<InsertOccupancyForecast>({
    resolver: zodResolver(insertOccupancyForecastSchema),
    defaultValues: {
      date: forecast?.date || selectedDate || new Date(),
      occupancyRate: forecast?.occupancyRate || "",
      totalRooms: forecast?.totalRooms || 100,
      occupiedRooms: forecast?.occupiedRooms || 0,
      staffingMultiplier: forecast?.staffingMultiplier || "1.0",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertOccupancyForecast) => {
      if (isEditing) {
        await apiRequest('PUT', `/api/occupancy/${forecast.id}`, data);
      } else {
        await apiRequest('POST', '/api/occupancy', data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/occupancy'] });
      toast({
        title: "Success",
        description: `Occupancy forecast ${isEditing ? 'updated' : 'created'} successfully`,
      });
      onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || `Failed to ${isEditing ? 'update' : 'create'} occupancy forecast`,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertOccupancyForecast) => {
    // Calculate occupied rooms if not provided
    if (!data.occupiedRooms && data.occupancyRate && data.totalRooms) {
      data.occupiedRooms = Math.round((parseFloat(data.occupancyRate) / 100) * data.totalRooms);
    }
    
    mutation.mutate(data);
  };

  const watchedOccupancyRate = form.watch("occupancyRate");
  const watchedTotalRooms = form.watch("totalRooms");

  // Auto-calculate occupied rooms when occupancy rate or total rooms change
  const handleCalculateOccupiedRooms = () => {
    if (watchedOccupancyRate && watchedTotalRooms) {
      const occupiedRooms = Math.round((parseFloat(watchedOccupancyRate) / 100) * watchedTotalRooms);
      form.setValue("occupiedRooms", occupiedRooms);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" data-testid="occupancy-form">
        <FormField
          control={form.control}
          name="date"
          render={({ field }) => (
            <FormItem className="flex flex-col">
              <FormLabel>Date</FormLabel>
              <Popover>
                <PopoverTrigger asChild>
                  <FormControl>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full pl-3 text-left font-normal",
                        !field.value && "text-muted-foreground"
                      )}
                      data-testid="button-select-date"
                    >
                      {field.value ? (
                        format(field.value, "PPP")
                      ) : (
                        <span>Pick a date</span>
                      )}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </FormControl>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={field.value}
                    onSelect={field.onChange}
                    disabled={(date) =>
                      date < new Date(new Date().setHours(0, 0, 0, 0))
                    }
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="occupancyRate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Occupancy Rate (%)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.01" 
                    min="0" 
                    max="100" 
                    placeholder="75.00" 
                    {...field} 
                    onBlur={(e) => {
                      field.onBlur();
                      handleCalculateOccupiedRooms();
                    }}
                    data-testid="input-occupancy-rate" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="staffingMultiplier"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Staffing Multiplier</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.1" 
                    min="0.1" 
                    max="3.0" 
                    placeholder="1.0" 
                    {...field} 
                    data-testid="input-staffing-multiplier" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="totalRooms"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Total Rooms</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1" 
                    placeholder="100" 
                    {...field} 
                    onChange={(e) => {
                      field.onChange(e.target.value ? parseInt(e.target.value) : 0);
                      setTimeout(handleCalculateOccupiedRooms, 100);
                    }}
                    data-testid="input-total-rooms" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="occupiedRooms"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Occupied Rooms</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="0" 
                    placeholder="75" 
                    {...field} 
                    onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : 0)}
                    data-testid="input-occupied-rooms" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="submit"
            disabled={mutation.isPending}
            className="bg-brand-blue hover:bg-blue-600"
            data-testid="button-submit-occupancy"
          >
            {mutation.isPending 
              ? 'Saving...' 
              : isEditing 
                ? 'Update Forecast' 
                : 'Add Forecast'
            }
          </Button>
        </div>
      </form>
    </Form>
  );
}
