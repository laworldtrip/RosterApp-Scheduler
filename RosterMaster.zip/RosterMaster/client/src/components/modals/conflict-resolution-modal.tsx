import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

interface ConflictResolutionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  conflict?: {
    employee: string;
    details: string;
  };
}

export default function ConflictResolutionModal({ 
  open, 
  onOpenChange,
  conflict = {
    employee: "Robert Taylor",
    details: "Monday: 9-5 PM conflicts with requested time off"
  }
}: ConflictResolutionModalProps) {
  const [resolution, setResolution] = useState("");
  const { toast } = useToast();

  const handleResolve = () => {
    if (!resolution) {
      toast({
        title: "Selection Required",
        description: "Please select a resolution option",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Conflict Resolved",
      description: `Applied resolution: ${resolution.replace(/([A-Z])/g, ' $1').toLowerCase()}`,
    });
    
    onOpenChange(false);
    setResolution("");
  };

  const handleClose = () => {
    onOpenChange(false);
    setResolution("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg" data-testid="conflict-resolution-modal">
        <DialogHeader>
          <DialogTitle>Resolve Scheduling Conflict</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <p className="text-sm text-slate-700 mb-2">
              <strong data-testid="text-conflict-employee">{conflict.employee}</strong> has conflicting shifts:
            </p>
            <div className="p-3 bg-red-50 border border-red-200 rounded">
              <p className="text-sm font-medium text-brand-red" data-testid="text-conflict-details">
                {conflict.details}
              </p>
            </div>
          </div>
          
          <div>
            <Label className="text-sm font-medium text-slate-700 mb-3 block">
              Resolution Options:
            </Label>
            <RadioGroup value={resolution} onValueChange={setResolution} data-testid="radiogroup-resolution">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="reassign" id="reassign" data-testid="radio-reassign" />
                  <Label htmlFor="reassign" className="text-sm text-slate-700">
                    Reassign shift to available staff
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="split" id="split" data-testid="radio-split" />
                  <Label htmlFor="split" className="text-sm text-slate-700">
                    Split shift between multiple staff
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="overtime" id="overtime" data-testid="radio-overtime" />
                  <Label htmlFor="overtime" className="text-sm text-slate-700">
                    Offer as overtime to existing staff
                  </Label>
                </div>
              </div>
            </RadioGroup>
          </div>
        </div>
        
        <div className="flex justify-end space-x-3 pt-4 border-t border-slate-200">
          <Button 
            variant="outline" 
            onClick={handleClose}
            data-testid="button-cancel-resolution"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleResolve}
            className="bg-brand-blue hover:bg-blue-600"
            data-testid="button-apply-resolution"
          >
            Apply Resolution
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
