import { format } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Edit } from "lucide-react";
import type { OccupancyForecast } from "@shared/schema";

interface OccupancyPanelProps {
  occupancy: OccupancyForecast[];
  weekStart: Date;
}

export default function OccupancyPanel({ occupancy, weekStart }: OccupancyPanelProps) {
  const handleEditOccupancy = () => {
    // TODO: Navigate to occupancy management page
    console.log('Edit occupancy clicked');
  };

  const getDayName = (dayIndex: number) => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[dayIndex];
  };

  const getProgressColor = (rate: number) => {
    if (rate >= 90) return "bg-brand-green";
    if (rate >= 75) return "bg-brand-blue";
    if (rate >= 50) return "bg-brand-amber";
    return "bg-slate-400";
  };

  // Generate 7 days from weekStart
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const date = new Date(weekStart);
    date.setDate(date.getDate() + i);
    return date;
  });

  const getOccupancyForDate = (date: Date) => {
    return occupancy.find(o => 
      format(new Date(o.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );
  };

  return (
    <Card data-testid="occupancy-panel">
      <CardHeader>
        <CardTitle>Hotel Occupancy</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {weekDays.map((date, index) => {
            const forecast = getOccupancyForDate(date);
            const rate = forecast ? parseFloat(forecast.occupancyRate) : 0;
            
            return (
              <div key={index} className="flex justify-between items-center" data-testid={`occupancy-day-${index}`}>
                <div>
                  <p className="text-sm font-medium text-slate-800" data-testid={`day-name-${index}`}>
                    {getDayName(date.getDay())}
                  </p>
                  <p className="text-xs text-slate-500" data-testid={`day-date-${index}`}>
                    {format(date, 'MMM dd')}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-slate-200 rounded-full h-2">
                    <Progress 
                      value={rate} 
                      className="h-2"
                      data-testid={`progress-${index}`}
                    />
                  </div>
                  <span className="text-sm font-medium text-slate-800 min-w-[35px]" data-testid={`rate-${index}`}>
                    {rate}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-4 pt-4 border-t border-slate-200">
          <Button 
            variant="outline" 
            onClick={handleEditOccupancy}
            className="w-full text-brand-blue hover:text-blue-600"
            data-testid="button-edit-occupancy"
          >
            <Edit className="w-4 h-4 mr-2" />
            Edit Forecasts
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
