import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserPlus, Send, Download, BarChart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function QuickActionsPanel() {
  const { toast } = useToast();

  const handleAddStaff = () => {
    // TODO: Navigate to staff management or open modal
    toast({
      title: "Navigate to Staff",
      description: "Redirecting to staff management page",
    });
  };

  const handleSendNotifications = () => {
    toast({
      title: "Notifications Sent",
      description: "Roster notifications have been sent to all staff members",
    });
  };

  const handleExportRoster = () => {
    toast({
      title: "Export Started",
      description: "Your roster PDF will be ready for download shortly",
    });
  };

  const handleViewReports = () => {
    toast({
      title: "Coming Soon",
      description: "Analytics and reporting features are in development",
    });
  };

  const actions = [
    {
      label: 'Add New Staff Member',
      icon: UserPlus,
      color: 'text-brand-blue',
      onClick: handleAddStaff,
      testId: 'button-add-staff'
    },
    {
      label: 'Send Roster Notifications',
      icon: Send,
      color: 'text-brand-green',
      onClick: handleSendNotifications,
      testId: 'button-send-notifications'
    },
    {
      label: 'Export Roster (PDF)',
      icon: Download,
      color: 'text-brand-amber',
      onClick: handleExportRoster,
      testId: 'button-export-roster'
    },
    {
      label: 'View Analytics',
      icon: BarChart,
      color: 'text-brand-blue',
      onClick: handleViewReports,
      testId: 'button-view-reports'
    }
  ];

  return (
    <Card data-testid="quick-actions-panel">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {actions.map((action, index) => {
          const IconComponent = action.icon;
          return (
            <Button
              key={index}
              variant="ghost"
              className="w-full justify-start text-left px-3 py-2 text-sm text-slate-700 hover:bg-slate-50"
              onClick={action.onClick}
              data-testid={action.testId}
            >
              <IconComponent className={`mr-3 ${action.color}`} size={16} />
              {action.label}
            </Button>
          );
        })}
      </CardContent>
    </Card>
  );
}
