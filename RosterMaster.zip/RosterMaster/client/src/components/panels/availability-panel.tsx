import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Info, CheckCircle, Calendar } from "lucide-react";

const availabilityAlerts = [
  {
    type: 'warning',
    employee: 'Sarah Wilson',
    message: 'Unavailable Wed-Fri (sick leave)',
    icon: AlertTriangle,
    bgColor: 'bg-amber-50',
    borderColor: 'border-amber-200',
    iconColor: 'text-brand-amber'
  },
  {
    type: 'info',
    employee: 'Mike Chen',
    message: 'Prefers morning shifts this week',
    icon: Info,
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200',
    iconColor: 'text-brand-blue'
  },
  {
    type: 'success',
    employee: 'Lisa Park',
    message: 'Available for extra shifts',
    icon: CheckCircle,
    bgColor: 'bg-green-50',
    borderColor: 'border-green-200',
    iconColor: 'text-brand-green'
  }
];

export default function AvailabilityPanel() {
  const handleManageAvailability = () => {
    // TODO: Navigate to availability management page
    console.log('Manage availability clicked');
  };

  return (
    <Card data-testid="availability-panel">
      <CardHeader>
        <CardTitle>Staff Availability</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {availabilityAlerts.length === 0 ? (
            <div className="text-center py-4 text-slate-500">
              No availability alerts at this time.
            </div>
          ) : (
            availabilityAlerts.map((alert, index) => {
              const IconComponent = alert.icon;
              return (
                <div 
                  key={index}
                  className={`flex items-start space-x-3 p-3 ${alert.bgColor} border ${alert.borderColor} rounded-lg`}
                  data-testid={`availability-alert-${index}`}
                >
                  <IconComponent className={`${alert.iconColor} mt-0.5`} size={16} />
                  <div>
                    <p className="text-sm font-medium text-slate-800" data-testid={`alert-employee-${index}`}>
                      {alert.employee}
                    </p>
                    <p className="text-xs text-slate-600" data-testid={`alert-message-${index}`}>
                      {alert.message}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="mt-4 pt-4 border-t border-slate-200">
          <Button 
            variant="outline" 
            onClick={handleManageAvailability}
            className="w-full text-brand-blue hover:text-blue-600"
            data-testid="button-manage-availability"
          >
            <Calendar className="w-4 h-4 mr-2" />
            Manage Availability
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
