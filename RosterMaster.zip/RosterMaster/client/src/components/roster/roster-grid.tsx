import { format, addDays, startOfWeek } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import ShiftCard from "./shift-card";
import type { Staff, Shift } from "@shared/schema";

interface RosterGridProps {
  staff: Staff[];
  shifts: (Shift & { staff: Staff })[];
  currentWeek: Date;
  onPreviousWeek?: () => void;
  onNextWeek?: () => void;
  onConflictClick?: () => void;
  editable?: boolean;
}

export default function RosterGrid({ 
  staff, 
  shifts, 
  currentWeek,
  onConflictClick,
  editable = false
}: RosterGridProps) {
  const weekStart = startOfWeek(currentWeek, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  const getShiftsForStaffAndDay = (staffId: string, date: Date) => {
    return shifts.filter(shift => 
      shift.staffId === staffId && 
      format(new Date(shift.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );
  };

  const getStaffTypeColor = (type: string) => {
    switch (type) {
      case 'full-time': return 'brand-blue';
      case 'part-time': return 'brand-green';
      case 'casual': return 'brand-amber';
      default: return 'slate';
    }
  };

  const totalHours = shifts.reduce((sum, shift) => sum + parseFloat(shift.hours || '0'), 0);

  const handleDropZoneClick = (staffId: string, date: Date) => {
    if (editable) {
      // TODO: Open shift creation modal
      console.log('Create shift for:', staffId, date);
    }
  };

  return (
    <Card data-testid="roster-grid">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Weekly Roster</CardTitle>
          <span className="text-sm text-slate-600" data-testid="text-current-week">
            {format(weekStart, 'MMM dd')} - {format(addDays(weekStart, 6), 'dd, yyyy')}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200">
                <th className="text-left py-3 px-2 text-sm font-medium text-slate-600 min-w-[180px]">
                  Staff
                </th>
                {dayNames.map((day, index) => (
                  <th key={day} className="text-center py-3 px-2 text-sm font-medium text-slate-600 min-w-[100px]" data-testid={`header-${day.toLowerCase()}`}>
                    {day}
                    <br />
                    <span className="text-xs text-slate-400">
                      {format(weekDays[index], 'dd')}
                    </span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {staff.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-8 text-slate-500">
                    No staff members available. Add staff members to create rosters.
                  </td>
                </tr>
              ) : (
                staff.map((staffMember) => {
                  const staffShifts = shifts.filter(shift => shift.staffId === staffMember.id);
                  const hasConflicts = staffShifts.some(shift => shift.conflicted);
                  
                  return (
                    <tr 
                      key={staffMember.id} 
                      className={`hover:bg-slate-50 ${hasConflicts ? 'bg-red-50' : ''}`}
                      data-testid={`row-staff-${staffMember.id}`}
                    >
                      <td className="py-3 px-2">
                        <div className="flex items-center space-x-3">
                          <Avatar className="w-8 h-8">
                            <AvatarFallback className="bg-slate-300 text-slate-600 text-xs">
                              {staffMember.firstName.charAt(0)}{staffMember.lastName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium text-slate-800" data-testid={`text-staff-name-${staffMember.id}`}>
                              {staffMember.firstName} {staffMember.lastName}
                            </p>
                            <div className="flex items-center space-x-2">
                              <Badge 
                                className={`text-xs ${getStaffTypeColor(staffMember.staffType)}`}
                                data-testid={`badge-staff-type-${staffMember.id}`}
                              >
                                {staffMember.staffType}
                              </Badge>
                              {hasConflicts && (
                                <span className="text-xs text-brand-red flex items-center space-x-1">
                                  <span>⚠</span>
                                  <span>Conflict</span>
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>
                      
                      {weekDays.map((date, dayIndex) => {
                        const dayShifts = getShiftsForStaffAndDay(staffMember.id, date);
                        
                        return (
                          <td key={dayIndex} className="py-3 px-2 text-center" data-testid={`cell-${staffMember.id}-${format(date, 'yyyy-MM-dd')}`}>
                            {dayShifts.length > 0 ? (
                              <div className="space-y-1">
                                {dayShifts.map((shift) => (
                                  <ShiftCard
                                    key={shift.id}
                                    shift={shift}
                                    staffType={staffMember.staffType}
                                    editable={editable}
                                    onClick={shift.conflicted ? onConflictClick : undefined}
                                  />
                                ))}
                              </div>
                            ) : (
                              <div 
                                className="h-6 border-2 border-dashed border-slate-300 rounded text-xs text-slate-400 flex items-center justify-center cursor-pointer hover:border-slate-400 transition-colors"
                                onClick={() => handleDropZoneClick(staffMember.id, date)}
                                data-testid={`dropzone-${staffMember.id}-${format(date, 'yyyy-MM-dd')}`}
                              >
                                {editable ? '+' : ''}
                              </div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 flex justify-between items-center text-sm text-slate-600">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-brand-blue rounded"></div>
              <span>Full-time</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-brand-green rounded"></div>
              <span>Part-time</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-brand-amber rounded"></div>
              <span>Casual</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-brand-red rounded"></div>
              <span>Conflict</span>
            </div>
          </div>
          <p data-testid="text-total-hours">
            Total Hours: <span className="font-semibold">{Math.round(totalHours)}</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
