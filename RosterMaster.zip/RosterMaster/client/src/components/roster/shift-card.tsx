import { cn } from "@/lib/utils";
import type { Shift } from "@shared/schema";

interface ShiftCardProps {
  shift: Shift;
  staffType: string;
  editable?: boolean;
  onClick?: () => void;
}

export default function ShiftCard({ shift, staffType, editable = false, onClick }: ShiftCardProps) {
  const getShiftColor = (type: string, hasConflict?: boolean) => {
    if (hasConflict) return 'bg-brand-red border-2 border-red-300';
    
    switch (type) {
      case 'full-time': return 'brand-blue';
      case 'part-time': return 'brand-green';
      case 'casual': return 'brand-amber';
      default: return 'bg-slate-500';
    }
  };

  const formatShiftTime = (startTime: string, endTime: string) => {
    // Convert HH:MM format to more readable format
    const formatTime = (time: string) => {
      const [hours, minutes] = time.split(':');
      const hour = parseInt(hours, 10);
      if (hour === 0) return '12AM';
      if (hour < 12) return `${hour}AM`;
      if (hour === 12) return '12PM';
      return `${hour - 12}PM`;
    };
    
    return `${formatTime(startTime)}-${formatTime(endTime)}`;
  };

  const isConflicted = (shift as any).conflicted;

  return (
    <div
      className={cn(
        "shift-card text-white text-xs px-2 py-1 rounded cursor-pointer transition-all",
        getShiftColor(staffType, isConflicted),
        editable && "hover:opacity-80"
      )}
      onClick={onClick}
      draggable={editable}
      data-testid={`shift-card-${shift.id}`}
    >
      <div className="font-medium" data-testid={`shift-time-${shift.id}`}>
        {formatShiftTime(shift.startTime, shift.endTime)}
      </div>
      {shift.isOvertime && (
        <div className="text-xs opacity-80">OT</div>
      )}
    </div>
  );
}
