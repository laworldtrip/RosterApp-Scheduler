import { format, addDays, startOfWeek, endOfWeek } from "date-fns";
import type { Staff, OccupancyForecast, Availability, Shift, InsertShift } from "@shared/schema";

export interface RosterGenerationOptions {
  startDate: Date;
  endDate: Date;
  staff: Staff[];
  occupancyForecasts: OccupancyForecast[];
  availability: Availability[];
  existingShifts: Shift[];
}

export interface RosterGenerationResult {
  shifts: InsertShift[];
  conflicts: string[];
  warnings: string[];
  statistics: {
    totalShifts: number;
    totalHours: number;
    staffDistribution: Record<string, number>;
    fairnessScore: number;
  };
}

export class RosterGenerator {
  private options: RosterGenerationOptions;

  constructor(options: RosterGenerationOptions) {
    this.options = options;
  }

  /**
   * Generate roster based on occupancy, availability, and fairness constraints
   */
  generateRoster(): RosterGenerationResult {
    const shifts: InsertShift[] = [];
    const conflicts: string[] = [];
    const warnings: string[] = [];
    
    // Initialize staff tracking
    const staffHours: Record<string, number> = {};
    const staffShiftCount: Record<string, number> = {};
    
    this.options.staff.forEach(staff => {
      staffHours[staff.id] = 0;
      staffShiftCount[staff.id] = 0;
    });

    // Generate shifts for each day in the range
    const currentDate = new Date(this.options.startDate);
    
    while (currentDate <= this.options.endDate) {
      const dayShifts = this.generateDayShifts(currentDate, staffHours, staffShiftCount);
      shifts.push(...dayShifts.shifts);
      conflicts.push(...dayShifts.conflicts);
      warnings.push(...dayShifts.warnings);
      
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Calculate statistics
    const statistics = this.calculateStatistics(shifts, staffHours, staffShiftCount);

    return {
      shifts,
      conflicts,
      warnings,
      statistics
    };
  }

  private generateDayShifts(
    date: Date, 
    staffHours: Record<string, number>,
    staffShiftCount: Record<string, number>
  ): { shifts: InsertShift[], conflicts: string[], warnings: string[] } {
    const shifts: InsertShift[] = [];
    const conflicts: string[] = [];
    const warnings: string[] = [];

    // Get occupancy forecast for this date
    const forecast = this.options.occupancyForecasts.find(f => 
      format(new Date(f.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );

    // Calculate required staff based on occupancy
    const occupancyRate = forecast ? parseFloat(forecast.occupancyRate) : 50;
    const staffingMultiplier = forecast ? parseFloat(forecast.staffingMultiplier) : 1.0;
    const requiredStaff = this.calculateRequiredStaff(occupancyRate, staffingMultiplier);

    // Define standard shifts
    const shiftTemplates = [
      { startTime: "06:00", endTime: "14:00", hours: 8, type: "morning" as const },
      { startTime: "09:00", endTime: "17:00", hours: 8, type: "morning" as const },
      { startTime: "14:00", endTime: "22:00", hours: 8, type: "afternoon" as const },
      { startTime: "22:00", endTime: "06:00", hours: 8, type: "night" as const },
    ];

    // Get available staff for this date
    const availableStaff = this.getAvailableStaff(date);
    
    // Prioritize staff assignment
    const prioritizedStaff = this.prioritizeStaff(availableStaff, staffHours, staffShiftCount, date);

    let assignedStaff = 0;
    let shiftIndex = 0;

    // Assign shifts based on priority and requirements
    for (const staff of prioritizedStaff) {
      if (assignedStaff >= requiredStaff.total) break;

      // Check if staff member already has a shift on this day
      const hasExistingShift = this.options.existingShifts.some(shift =>
        shift.staffId === staff.id && 
        format(new Date(shift.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
      );

      if (hasExistingShift) {
        continue;
      }

      // Select appropriate shift template
      const shiftTemplate = shiftTemplates[shiftIndex % shiftTemplates.length];
      
      // Check for conflicts
      const staffConflicts = this.checkStaffConflicts(staff, date, shiftTemplate.startTime, shiftTemplate.endTime);
      
      if (staffConflicts.length > 0) {
        conflicts.push(...staffConflicts.map(c => `${staff.firstName} ${staff.lastName}: ${c}`));
        continue;
      }

      // Create shift
      const shift: InsertShift = {
        staffId: staff.id,
        date: new Date(date),
        startTime: shiftTemplate.startTime,
        endTime: shiftTemplate.endTime,
        shiftType: shiftTemplate.type,
        hours: shiftTemplate.hours.toString(),
        isOvertime: this.isOvertimeShift(staff, staffHours[staff.id], shiftTemplate.hours),
        notes: forecast ? `Auto-generated for ${occupancyRate}% occupancy` : 'Auto-generated shift'
      };

      shifts.push(shift);
      staffHours[staff.id] += shiftTemplate.hours;
      staffShiftCount[staff.id] += 1;
      assignedStaff++;
      shiftIndex++;
    }

    // Check if we have enough coverage
    if (assignedStaff < requiredStaff.minimum) {
      warnings.push(`${format(date, 'yyyy-MM-dd')}: Only ${assignedStaff} staff assigned, need minimum ${requiredStaff.minimum}`);
    }

    return { shifts, conflicts, warnings };
  }

  private calculateRequiredStaff(occupancyRate: number, staffingMultiplier: number): { minimum: number, optimal: number, total: number } {
    // Base calculation: 1 staff per 25% occupancy
    const baseStaff = Math.ceil(occupancyRate / 25);
    
    // Apply staffing multiplier
    const optimal = Math.ceil(baseStaff * staffingMultiplier);
    const minimum = Math.max(1, Math.floor(optimal * 0.8));
    const total = optimal;

    return { minimum, optimal, total };
  }

  private getAvailableStaff(date: Date): Staff[] {
    const dayOfWeek = date.getDay();
    
    return this.options.staff.filter(staff => {
      // Check if staff is active
      if (!staff.isActive) return false;

      // Check specific date availability
      const specificAvailability = this.options.availability.find(a =>
        a.staffId === staff.id && 
        a.date &&
        format(new Date(a.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
      );

      if (specificAvailability) {
        return specificAvailability.status === 'available' || specificAvailability.status === 'preferred';
      }

      // Check general availability for day of week
      const generalAvailability = this.options.availability.find(a =>
        a.staffId === staff.id && 
        a.dayOfWeek === dayOfWeek &&
        !a.date
      );

      if (generalAvailability) {
        return generalAvailability.status === 'available' || generalAvailability.status === 'preferred';
      }

      // Default to available if no specific restrictions
      return true;
    });
  }

  private prioritizeStaff(
    availableStaff: Staff[], 
    staffHours: Record<string, number>,
    staffShiftCount: Record<string, number>,
    date: Date
  ): Staff[] {
    return availableStaff.sort((a, b) => {
      // Priority 1: Staff type (full-time first, then part-time, then casual)
      const typeOrder = { 'full-time': 0, 'part-time': 1, 'casual': 2 };
      const typeDiff = typeOrder[a.staffType] - typeOrder[b.staffType];
      if (typeDiff !== 0) return typeDiff;

      // Priority 2: Contracted hours obligation (full-time staff needing hours)
      if (a.staffType === 'full-time' && b.staffType === 'full-time') {
        const aHoursNeeded = Math.max(0, (a.contractedHours || 40) - staffHours[a.id]);
        const bHoursNeeded = Math.max(0, (b.contractedHours || 40) - staffHours[b.id]);
        if (aHoursNeeded !== bHoursNeeded) {
          return bHoursNeeded - aHoursNeeded; // More hours needed = higher priority
        }
      }

      // Priority 3: Fair distribution (fewer shifts = higher priority)
      const shiftDiff = staffShiftCount[a.id] - staffShiftCount[b.id];
      if (shiftDiff !== 0) return shiftDiff;

      // Priority 4: Preferred availability for this day
      const dayOfWeek = date.getDay();
      const aPreferred = this.options.availability.some(av =>
        av.staffId === a.id && 
        ((av.dayOfWeek === dayOfWeek && !av.date) || 
         (av.date && format(new Date(av.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd'))) &&
        av.status === 'preferred'
      );
      const bPreferred = this.options.availability.some(av =>
        av.staffId === b.id && 
        ((av.dayOfWeek === dayOfWeek && !av.date) || 
         (av.date && format(new Date(av.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd'))) &&
        av.status === 'preferred'
      );
      
      if (aPreferred && !bPreferred) return -1;
      if (!aPreferred && bPreferred) return 1;

      return 0;
    });
  }

  private checkStaffConflicts(staff: Staff, date: Date, startTime: string, endTime: string): string[] {
    const conflicts: string[] = [];
    const dayOfWeek = date.getDay();

    // Check for unavailability
    const unavailable = this.options.availability.find(a =>
      a.staffId === staff.id &&
      a.status === 'unavailable' &&
      ((a.dayOfWeek === dayOfWeek && !a.date) ||
       (a.date && format(new Date(a.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')))
    );

    if (unavailable) {
      conflicts.push(`Unavailable on ${format(date, 'EEEE')}`);
    }

    // Check for existing shifts on the same day
    const existingShift = this.options.existingShifts.find(shift =>
      shift.staffId === staff.id &&
      format(new Date(shift.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );

    if (existingShift) {
      conflicts.push(`Already scheduled ${existingShift.startTime}-${existingShift.endTime}`);
    }

    // Check time constraints from availability
    const timeAvailability = this.options.availability.find(a =>
      a.staffId === staff.id &&
      ((a.dayOfWeek === dayOfWeek && !a.date) ||
       (a.date && format(new Date(a.date), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd'))) &&
      a.startTime && a.endTime
    );

    if (timeAvailability && timeAvailability.startTime && timeAvailability.endTime) {
      const availableStart = timeAvailability.startTime;
      const availableEnd = timeAvailability.endTime;
      
      if (startTime < availableStart || endTime > availableEnd) {
        conflicts.push(`Not available ${startTime}-${endTime} (available ${availableStart}-${availableEnd})`);
      }
    }

    return conflicts;
  }

  private isOvertimeShift(staff: Staff, currentHours: number, shiftHours: number): boolean {
    if (!staff.contractedHours) return false;
    
    // Simple weekly overtime check
    return (currentHours + shiftHours) > staff.contractedHours;
  }

  private calculateStatistics(
    shifts: InsertShift[], 
    staffHours: Record<string, number>,
    staffShiftCount: Record<string, number>
  ) {
    const totalShifts = shifts.length;
    const totalHours = shifts.reduce((sum, shift) => sum + parseFloat(shift.hours), 0);
    
    // Staff type distribution
    const staffDistribution: Record<string, number> = {
      'full-time': 0,
      'part-time': 0,
      'casual': 0
    };

    this.options.staff.forEach(staff => {
      staffDistribution[staff.staffType] += staffShiftCount[staff.id] || 0;
    });

    // Calculate fairness score (lower variance = more fair)
    const shiftCounts = Object.values(staffShiftCount);
    const meanShifts = shiftCounts.reduce((sum, count) => sum + count, 0) / shiftCounts.length;
    const variance = shiftCounts.reduce((sum, count) => sum + Math.pow(count - meanShifts, 2), 0) / shiftCounts.length;
    const fairnessScore = Math.max(0, 100 - (variance * 10)); // Convert to 0-100 scale

    return {
      totalShifts,
      totalHours,
      staffDistribution,
      fairnessScore: Math.round(fairnessScore)
    };
  }
}

/**
 * Helper function to generate roster
 */
export async function generateRoster(options: RosterGenerationOptions): Promise<RosterGenerationResult> {
  const generator = new RosterGenerator(options);
  return generator.generateRoster();
}

/**
 * Validate roster generation options
 */
export function validateRosterOptions(options: RosterGenerationOptions): string[] {
  const errors: string[] = [];

  if (options.startDate >= options.endDate) {
    errors.push("Start date must be before end date");
  }

  if (options.staff.length === 0) {
    errors.push("At least one staff member is required");
  }

  const activeStaff = options.staff.filter(s => s.isActive);
  if (activeStaff.length === 0) {
    errors.push("At least one active staff member is required");
  }

  return errors;
}
