import { createContext, useContext, useState, ReactNode } from 'react';
import { useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from './queryClient';
import { useToast } from '@/hooks/use-toast';
import type { Shift, InsertShift } from '@shared/schema';

interface DragDropContextType {
  draggedShift: Shift | null;
  isDragging: boolean;
  startDrag: (shift: Shift) => void;
  endDrag: () => void;
  moveShift: (shiftId: string, newStaffId: string, newDate: Date) => Promise<void>;
  createShift: (staffId: string, date: Date, shiftData: Partial<InsertShift>) => Promise<void>;
  deleteShift: (shiftId: string) => Promise<void>;
}

const DragDropContext = createContext<DragDropContextType | null>(null);

export function useDragDrop() {
  const context = useContext(DragDropContext);
  if (!context) {
    throw new Error('useDragDrop must be used within a DragDropContextProvider');
  }
  return context;
}

interface DragDropContextProviderProps {
  children: ReactNode;
}

export function DragDropContextProvider({ children }: DragDropContextProviderProps) {
  const [draggedShift, setDraggedShift] = useState<Shift | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();

  const moveShiftMutation = useMutation({
    mutationFn: async ({ shiftId, staffId, date }: { shiftId: string, staffId: string, date: Date }) => {
      await apiRequest('PUT', `/api/shifts/${shiftId}`, {
        staffId,
        date: date.toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/shifts'] });
      toast({
        title: "Shift Moved",
        description: "Shift has been successfully moved",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to move shift",
        variant: "destructive",
      });
    },
  });

  const createShiftMutation = useMutation({
    mutationFn: async (shiftData: InsertShift) => {
      await apiRequest('POST', '/api/shifts', shiftData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/shifts'] });
      toast({
        title: "Shift Created",
        description: "New shift has been created successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create shift",
        variant: "destructive",
      });
    },
  });

  const deleteShiftMutation = useMutation({
    mutationFn: async (shiftId: string) => {
      await apiRequest('DELETE', `/api/shifts/${shiftId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/shifts'] });
      toast({
        title: "Shift Deleted",
        description: "Shift has been deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete shift",
        variant: "destructive",
      });
    },
  });

  const startDrag = (shift: Shift) => {
    setDraggedShift(shift);
    setIsDragging(true);
  };

  const endDrag = () => {
    setDraggedShift(null);
    setIsDragging(false);
  };

  const moveShift = async (shiftId: string, newStaffId: string, newDate: Date) => {
    try {
      await moveShiftMutation.mutateAsync({ shiftId, staffId: newStaffId, date: newDate });
    } catch (error) {
      // Error handling is done in the mutation
      console.error('Failed to move shift:', error);
    }
  };

  const createShift = async (staffId: string, date: Date, shiftData: Partial<InsertShift>) => {
    const defaultShiftData: InsertShift = {
      staffId,
      date,
      startTime: "09:00",
      endTime: "17:00",
      shiftType: "morning",
      hours: "8.0",
      isOvertime: false,
      ...shiftData,
    };

    try {
      await createShiftMutation.mutateAsync(defaultShiftData);
    } catch (error) {
      // Error handling is done in the mutation
      console.error('Failed to create shift:', error);
    }
  };

  const deleteShift = async (shiftId: string) => {
    try {
      await deleteShiftMutation.mutateAsync(shiftId);
    } catch (error) {
      // Error handling is done in the mutation
      console.error('Failed to delete shift:', error);
    }
  };

  const value: DragDropContextType = {
    draggedShift,
    isDragging,
    startDrag,
    endDrag,
    moveShift,
    createShift,
    deleteShift,
  };

  return (
    <DragDropContext.Provider value={value}>
      {children}
    </DragDropContext.Provider>
  );
}

// Custom hook for drag and drop event handlers
export function useDragHandlers() {
  const { startDrag, endDrag, moveShift, createShift, draggedShift } = useDragDrop();

  const handleDragStart = (shift: Shift) => (e: React.DragEvent) => {
    startDrag(shift);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', shift.id);
  };

  const handleDragEnd = () => {
    endDrag();
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (staffId: string, date: Date) => (e: React.DragEvent) => {
    e.preventDefault();
    
    const shiftId = e.dataTransfer.getData('text/plain');
    
    if (draggedShift && shiftId === draggedShift.id) {
      // Move existing shift
      moveShift(shiftId, staffId, date);
    } else {
      // Create new shift if no dragged shift (clicked on empty slot)
      createShift(staffId, date, {
        startTime: "09:00",
        endTime: "17:00",
        shiftType: "morning",
        hours: "8.0",
      });
    }
    
    endDrag();
  };

  const handleDropZoneEnter = (e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.add('drag-over');
  };

  const handleDropZoneLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');
  };

  return {
    handleDragStart,
    handleDragEnd,
    handleDragOver,
    handleDrop,
    handleDropZoneEnter,
    handleDropZoneLeave,
  };
}
