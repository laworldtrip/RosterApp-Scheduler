import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, decimal, boolean, pgEnum } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const staffTypeEnum = pgEnum('staff_type', ['full-time', 'part-time', 'casual']);
export const shiftTypeEnum = pgEnum('shift_type', ['morning', 'afternoon', 'night', 'split']);
export const availabilityStatusEnum = pgEnum('availability_status', ['available', 'unavailable', 'preferred', 'overtime']);

// Users table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default('manager'),
});

// Staff table
export const staff = pgTable("staff", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  staffType: staffTypeEnum("staff_type").notNull(),
  hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }),
  contractedHours: integer("contracted_hours"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Availability table
export const availability = pgTable("availability", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  staffId: varchar("staff_id").notNull().references(() => staff.id, { onDelete: "cascade" }),
  dayOfWeek: integer("day_of_week").notNull(), // 0-6 (Sunday-Saturday)
  startTime: text("start_time").notNull(), // HH:MM format
  endTime: text("end_time").notNull(), // HH:MM format
  status: availabilityStatusEnum("status").notNull().default('available'),
  date: timestamp("date"), // Specific date override
  notes: text("notes"),
});

// Occupancy forecast table
export const occupancyForecast = pgTable("occupancy_forecast", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: timestamp("date").notNull(),
  occupancyRate: decimal("occupancy_rate", { precision: 5, scale: 2 }).notNull(),
  totalRooms: integer("total_rooms").notNull(),
  occupiedRooms: integer("occupied_rooms").notNull(),
  staffingMultiplier: decimal("staffing_multiplier", { precision: 3, scale: 2 }).notNull().default('1.0'),
});

// Shifts table
export const shifts = pgTable("shifts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  staffId: varchar("staff_id").notNull().references(() => staff.id, { onDelete: "cascade" }),
  date: timestamp("date").notNull(),
  startTime: text("start_time").notNull(), // HH:MM format
  endTime: text("end_time").notNull(), // HH:MM format
  shiftType: shiftTypeEnum("shift_type").notNull(),
  hours: decimal("hours", { precision: 4, scale: 2 }).notNull(),
  isOvertime: boolean("is_overtime").notNull().default(false),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Roster template table
export const rosterTemplates = pgTable("roster_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  templateData: text("template_data").notNull(), // JSON string
  isDefault: boolean("is_default").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Relations
export const staffRelations = relations(staff, ({ many }) => ({
  availability: many(availability),
  shifts: many(shifts),
}));

export const availabilityRelations = relations(availability, ({ one }) => ({
  staff: one(staff, {
    fields: [availability.staffId],
    references: [staff.id],
  }),
}));

export const shiftsRelations = relations(shifts, ({ one }) => ({
  staff: one(staff, {
    fields: [shifts.staffId],
    references: [staff.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertStaffSchema = createInsertSchema(staff).omit({ id: true, createdAt: true });
export const insertAvailabilitySchema = createInsertSchema(availability).omit({ id: true });
export const insertOccupancyForecastSchema = createInsertSchema(occupancyForecast).omit({ id: true });
export const insertShiftSchema = createInsertSchema(shifts).omit({ id: true, createdAt: true });
export const insertRosterTemplateSchema = createInsertSchema(rosterTemplates).omit({ id: true, createdAt: true });

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Staff = typeof staff.$inferSelect;
export type InsertStaff = z.infer<typeof insertStaffSchema>;
export type Availability = typeof availability.$inferSelect;
export type InsertAvailability = z.infer<typeof insertAvailabilitySchema>;
export type OccupancyForecast = typeof occupancyForecast.$inferSelect;
export type InsertOccupancyForecast = z.infer<typeof insertOccupancyForecastSchema>;
export type Shift = typeof shifts.$inferSelect;
export type InsertShift = z.infer<typeof insertShiftSchema>;
export type RosterTemplate = typeof rosterTemplates.$inferSelect;
export type InsertRosterTemplate = z.infer<typeof insertRosterTemplateSchema>;
