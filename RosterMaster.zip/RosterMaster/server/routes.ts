import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStaffSchema, insertAvailabilitySchema, insertOccupancyForecastSchema, insertShiftSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Staff routes
  app.get("/api/staff", async (req, res) => {
    try {
      const staff = await storage.getAllStaff();
      res.json(staff);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch staff" });
    }
  });

  app.post("/api/staff", async (req, res) => {
    try {
      const validatedData = insertStaffSchema.parse(req.body);
      const staff = await storage.createStaff(validatedData);
      res.status(201).json(staff);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create staff member" });
      }
    }
  });

  app.put("/api/staff/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = insertStaffSchema.partial().parse(req.body);
      const staff = await storage.updateStaff(id, validatedData);
      res.json(staff);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update staff member" });
      }
    }
  });

  app.delete("/api/staff/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteStaff(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete staff member" });
    }
  });

  // Availability routes
  app.get("/api/availability/:staffId", async (req, res) => {
    try {
      const { staffId } = req.params;
      const availability = await storage.getAvailabilityByStaff(staffId);
      res.json(availability);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch availability" });
    }
  });

  app.post("/api/availability", async (req, res) => {
    try {
      const validatedData = insertAvailabilitySchema.parse(req.body);
      const availability = await storage.createAvailability(validatedData);
      res.status(201).json(availability);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create availability" });
      }
    }
  });

  // Occupancy forecast routes
  app.get("/api/occupancy", async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "startDate and endDate are required" });
      }
      
      const start = new Date(startDate as string);
      const end = new Date(endDate as string);
      const forecasts = await storage.getOccupancyForecast(start, end);
      res.json(forecasts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch occupancy forecast" });
    }
  });

  app.post("/api/occupancy", async (req, res) => {
    try {
      const validatedData = insertOccupancyForecastSchema.parse(req.body);
      const forecast = await storage.createOccupancyForecast(validatedData);
      res.status(201).json(forecast);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create occupancy forecast" });
      }
    }
  });

  app.put("/api/occupancy/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = insertOccupancyForecastSchema.partial().parse(req.body);
      const forecast = await storage.updateOccupancyForecast(id, validatedData);
      res.json(forecast);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update occupancy forecast" });
      }
    }
  });

  // Shifts routes
  app.get("/api/shifts", async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "startDate and endDate are required" });
      }
      
      const start = new Date(startDate as string);
      const end = new Date(endDate as string);
      const shifts = await storage.getShiftsByDateRange(start, end);
      res.json(shifts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shifts" });
    }
  });

  app.post("/api/shifts", async (req, res) => {
    try {
      const validatedData = insertShiftSchema.parse(req.body);
      const shift = await storage.createShift(validatedData);
      res.status(201).json(shift);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create shift" });
      }
    }
  });

  app.put("/api/shifts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const validatedData = insertShiftSchema.partial().parse(req.body);
      const shift = await storage.updateShift(id, validatedData);
      res.json(shift);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update shift" });
      }
    }
  });

  app.delete("/api/shifts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteShift(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete shift" });
    }
  });

  // Auto-generate roster endpoint
  app.post("/api/roster/generate", async (req, res) => {
    try {
      const { startDate, endDate } = req.body;
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "startDate and endDate are required" });
      }
      
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      // Get all active staff
      const allStaff = await storage.getAllStaff();
      
      // Get occupancy forecast for the period
      const occupancyForecasts = await storage.getOccupancyForecast(start, end);
      
      // Get existing shifts to avoid conflicts
      const existingShifts = await storage.getShiftsByDateRange(start, end);
      
      // Simple roster generation logic (can be enhanced)
      const generatedShifts = [];
      const currentDate = new Date(start);
      
      while (currentDate <= end) {
        const dayOfWeek = currentDate.getDay();
        const occupancy = occupancyForecasts.find(f => 
          f.date.toDateString() === currentDate.toDateString()
        );
        
        const requiredStaff = Math.ceil((occupancy?.occupancyRate || 50) / 25); // Simple calculation
        
        // Assign shifts to staff based on type priority
        const fullTimeStaff = allStaff.filter(s => s.staffType === 'full-time');
        const partTimeStaff = allStaff.filter(s => s.staffType === 'part-time');
        const casualStaff = allStaff.filter(s => s.staffType === 'casual');
        
        let assignedCount = 0;
        
        // Assign full-time staff first
        for (const staff of fullTimeStaff.slice(0, Math.min(requiredStaff, fullTimeStaff.length))) {
          if (assignedCount >= requiredStaff) break;
          
          generatedShifts.push({
            staffId: staff.id,
            date: new Date(currentDate),
            startTime: "09:00",
            endTime: "17:00",
            shiftType: "morning" as const,
            hours: "8.0",
            isOvertime: false,
          });
          assignedCount++;
        }
        
        // Fill remaining with part-time staff
        for (const staff of partTimeStaff.slice(0, Math.max(0, requiredStaff - assignedCount))) {
          if (assignedCount >= requiredStaff) break;
          
          generatedShifts.push({
            staffId: staff.id,
            date: new Date(currentDate),
            startTime: "06:00",
            endTime: "14:00",
            shiftType: "morning" as const,
            hours: "8.0",
            isOvertime: false,
          });
          assignedCount++;
        }
        
        currentDate.setDate(currentDate.getDate() + 1);
      }
      
      res.json({ generatedShifts, message: "Roster generated successfully" });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to generate roster" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
