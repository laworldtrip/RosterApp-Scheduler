import { 
  staff, availability, occupancyForecast, shifts, rosterTemplates,
  type Staff, type InsertStaff, type Availability, type InsertAvailability,
  type OccupancyForecast, type InsertOccupancyForecast, type Shift, type InsertShift,
  type RosterTemplate, type InsertRosterTemplate, type User, type InsertUser
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, sql } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Staff methods
  getAllStaff(): Promise<Staff[]>;
  getStaff(id: string): Promise<Staff | undefined>;
  createStaff(staff: InsertStaff): Promise<Staff>;
  updateStaff(id: string, staff: Partial<InsertStaff>): Promise<Staff>;
  deleteStaff(id: string): Promise<void>;

  // Availability methods
  getAvailabilityByStaff(staffId: string): Promise<Availability[]>;
  getAvailabilityByDateRange(startDate: Date, endDate: Date): Promise<Availability[]>;
  createAvailability(availability: InsertAvailability): Promise<Availability>;
  updateAvailability(id: string, availability: Partial<InsertAvailability>): Promise<Availability>;
  deleteAvailability(id: string): Promise<void>;

  // Occupancy methods
  getOccupancyForecast(startDate: Date, endDate: Date): Promise<OccupancyForecast[]>;
  createOccupancyForecast(forecast: InsertOccupancyForecast): Promise<OccupancyForecast>;
  updateOccupancyForecast(id: string, forecast: Partial<InsertOccupancyForecast>): Promise<OccupancyForecast>;

  // Shift methods
  getShiftsByDateRange(startDate: Date, endDate: Date): Promise<(Shift & { staff: Staff })[]>;
  getShiftsByStaff(staffId: string, startDate: Date, endDate: Date): Promise<Shift[]>;
  createShift(shift: InsertShift): Promise<Shift>;
  updateShift(id: string, shift: Partial<InsertShift>): Promise<Shift>;
  deleteShift(id: string): Promise<void>;

  // Roster template methods
  getRosterTemplates(): Promise<RosterTemplate[]>;
  createRosterTemplate(template: InsertRosterTemplate): Promise<RosterTemplate>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllStaff(): Promise<Staff[]> {
    return await db.select().from(staff).where(eq(staff.isActive, true));
  }

  async getStaff(id: string): Promise<Staff | undefined> {
    const [staffMember] = await db.select().from(staff).where(eq(staff.id, id));
    return staffMember || undefined;
  }

  async createStaff(insertStaff: InsertStaff): Promise<Staff> {
    const [staffMember] = await db.insert(staff).values(insertStaff).returning();
    return staffMember;
  }

  async updateStaff(id: string, updateStaff: Partial<InsertStaff>): Promise<Staff> {
    const [staffMember] = await db
      .update(staff)
      .set(updateStaff)
      .where(eq(staff.id, id))
      .returning();
    return staffMember;
  }

  async deleteStaff(id: string): Promise<void> {
    await db.update(staff).set({ isActive: false }).where(eq(staff.id, id));
  }

  async getAvailabilityByStaff(staffId: string): Promise<Availability[]> {
    return await db.select().from(availability).where(eq(availability.staffId, staffId));
  }

  async getAvailabilityByDateRange(startDate: Date, endDate: Date): Promise<Availability[]> {
    return await db.select().from(availability)
      .where(
        and(
          gte(availability.date, startDate),
          lte(availability.date, endDate)
        )
      );
  }

  async createAvailability(insertAvailability: InsertAvailability): Promise<Availability> {
    const [availabilityRecord] = await db.insert(availability).values(insertAvailability).returning();
    return availabilityRecord;
  }

  async updateAvailability(id: string, updateAvailability: Partial<InsertAvailability>): Promise<Availability> {
    const [availabilityRecord] = await db
      .update(availability)
      .set(updateAvailability)
      .where(eq(availability.id, id))
      .returning();
    return availabilityRecord;
  }

  async deleteAvailability(id: string): Promise<void> {
    await db.delete(availability).where(eq(availability.id, id));
  }

  async getOccupancyForecast(startDate: Date, endDate: Date): Promise<OccupancyForecast[]> {
    return await db.select().from(occupancyForecast)
      .where(
        and(
          gte(occupancyForecast.date, startDate),
          lte(occupancyForecast.date, endDate)
        )
      );
  }

  async createOccupancyForecast(insertForecast: InsertOccupancyForecast): Promise<OccupancyForecast> {
    const [forecast] = await db.insert(occupancyForecast).values(insertForecast).returning();
    return forecast;
  }

  async updateOccupancyForecast(id: string, updateForecast: Partial<InsertOccupancyForecast>): Promise<OccupancyForecast> {
    const [forecast] = await db
      .update(occupancyForecast)
      .set(updateForecast)
      .where(eq(occupancyForecast.id, id))
      .returning();
    return forecast;
  }

  async getShiftsByDateRange(startDate: Date, endDate: Date): Promise<(Shift & { staff: Staff })[]> {
    return await db.select({
      id: shifts.id,
      staffId: shifts.staffId,
      date: shifts.date,
      startTime: shifts.startTime,
      endTime: shifts.endTime,
      shiftType: shifts.shiftType,
      hours: shifts.hours,
      isOvertime: shifts.isOvertime,
      notes: shifts.notes,
      createdAt: shifts.createdAt,
      staff: {
        id: staff.id,
        firstName: staff.firstName,
        lastName: staff.lastName,
        email: staff.email,
        phone: staff.phone,
        staffType: staff.staffType,
        hourlyRate: staff.hourlyRate,
        contractedHours: staff.contractedHours,
        isActive: staff.isActive,
        createdAt: staff.createdAt,
      }
    })
    .from(shifts)
    .innerJoin(staff, eq(shifts.staffId, staff.id))
    .where(
      and(
        gte(shifts.date, startDate),
        lte(shifts.date, endDate)
      )
    );
  }

  async getShiftsByStaff(staffId: string, startDate: Date, endDate: Date): Promise<Shift[]> {
    return await db.select().from(shifts)
      .where(
        and(
          eq(shifts.staffId, staffId),
          gte(shifts.date, startDate),
          lte(shifts.date, endDate)
        )
      );
  }

  async createShift(insertShift: InsertShift): Promise<Shift> {
    const [shift] = await db.insert(shifts).values(insertShift).returning();
    return shift;
  }

  async updateShift(id: string, updateShift: Partial<InsertShift>): Promise<Shift> {
    const [shift] = await db
      .update(shifts)
      .set(updateShift)
      .where(eq(shifts.id, id))
      .returning();
    return shift;
  }

  async deleteShift(id: string): Promise<void> {
    await db.delete(shifts).where(eq(shifts.id, id));
  }

  async getRosterTemplates(): Promise<RosterTemplate[]> {
    return await db.select().from(rosterTemplates);
  }

  async createRosterTemplate(insertTemplate: InsertRosterTemplate): Promise<RosterTemplate> {
    const [template] = await db.insert(rosterTemplates).values(insertTemplate).returning();
    return template;
  }
}

export const storage = new DatabaseStorage();
